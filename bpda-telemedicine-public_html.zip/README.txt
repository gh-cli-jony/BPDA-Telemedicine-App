BPDA Telemedicine - Frontend Build
==================================

Upload all files in this folder to your hosting public_html directory.

To point the frontend to your live backend API:
1. Open config.js in a text editor.
2. Replace the empty string with your API root URL, for example:

   window.BPDA_API_BASE_URL = "https://your-domain.com/api";

3. Save and upload config.js along with the other files.

No rebuild is required when only config.js changes.
